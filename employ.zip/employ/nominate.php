<html>
<head>
<p><b>NOMINATE A TEACHER</b></p>
<title>WANT TO NOMINATE A TEACHER ?</TITLE>

<body>
<a href="http://localhost/employ/about1/about.php">Click here to Nominate a teacher</a>
</body>
</html>


