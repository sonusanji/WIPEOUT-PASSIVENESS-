OBJECTIVE:Unemployment in India is increasing marginally and is projected to increase from 17.7 million last year to 17.8 million in 2017 and 18 million next year. In percentage terms, unemployment rate will remain at 3.4 per cent in 2017-18. This app gives a solution for unemployment by allowing the users to either teach (be a mentor) and earn or learn (be a mentee) from a mentor and use the learnt skills to find employment.

Basically, the user has a login asking whether he/she likes to teach or learn. If the user chooses to be a mentor, then certain credentials like his email,skills,linked-in handle, and on what the user wants to teach is recorded. He/she can teach for free, or earn . If the user choose to be a mentee and wants to learn , then the respective credentials and what he/she wants to learn is recorded. A mapping is done between the data of the mentee and mentor and taking in to account if the learner wants to pay , and match of the skills, etc. Finally the matched teacher details gets popped up or respectively the learner details gets popped up .  The skills covered is a wide range from education (coding ) to driving  to any miscellaneous things.

OTHER PROVISIONS : The learner can review the teacher after the learning. 
This app also provides a EXPLORE option that allows the user to search for teachers with any skills from the recorded database and view their ratings. And also the mentors can advertise their ratings with facebook and social media links provided in the app which indirectly advertise our app.
There is also a "CHAT ROOM "that enable users to have discussions.

GOAL- This app helps to create employment and also to a platform for people to learn.
I have been successful in developing a complete working prototype of the above mentioned projects with all the components working.

In future, I would like to add validation checks to this project and build the database and deploy it in real environment.

WIPE OUT UNENGAGEDNESS/ PASSIVENESS  - ERADICATE UNEMPLOYMENT!!!
<a href="https://twitter.com/intent/tweet?button_hashtag=ERADICATEUMNEMPLOYMENT!&text=Check%20out%20WIPEOUT%PASSIVENESS" class="twitter-hashtag-button" data-size="large">Tweet #ERADICATEUNEMPLOYMENT!</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
