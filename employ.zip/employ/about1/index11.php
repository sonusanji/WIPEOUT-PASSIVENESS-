
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>INTRO</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-chunkfive.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="logo">
        <h1><a href="index.php">WIPEOUT<span>-</span>PASSIVENESS <small>ERADICATE UNEMPLOYMENT</small><small>Entrepreneurs for Entrepreneurship</small></a></h1>
      </div>
      <div class="menu_nav">
        <ul>
          <!--<li class="active"><a href="index11.php"><span>Home</span></a></li>-->
          
          <li><a href="index212.php"><span>Vision</span></a></li>
         
          <li><a href="s_up/signup.php"><span>Sign-Up</span></a></li>
             <li><a href="journal.php"><span>JOURNAL</span></a></li>
			 <li><a href="s_up/login.php"><span>LOGIN</span></a></li>
        </ul>
      </div>
	  
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider"> <a href="#"></a><img src="images/slide2.jpg" style="width:700px;height:360px;"></a> <a href="#"><img src="images/empoweredv1.jpg" style="width:12000px;height:1000px;"><img src="images/slide3.jpg" style="width:700px;height:360px;"></a> </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
   <section id="contact" class="templatemo-section">
		<div>
   
			<a class="twitter-share-button"
  href="https://twitter.com/intent/tweet?text=WIPEOUT%20PASSIVENESS"
  data-size="large">
TWEET #ERADICATEUNEMPLOYMENT</a>
</div>
</section>
					
						

      </body>
</html>
