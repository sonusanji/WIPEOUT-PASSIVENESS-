
<html>
	<head>
		<title>Journal entry</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>
	<body>

		<!-- Banner -->
			<section id="banner">
				<div class="inner split">
					<section>
						<h2> What can document our struggles, wins, relationships, and lives; clear our minds and serve as a canvas to which we can spill our thoughts into.  The answer is journal writing!!</h2>
					</section>
					<section>
						<p></p>
						<ul class="actions">
							<li><a href="#" class="button special">Scroll down</a></li>
						</ul>
					</section>
				</div>
			</section>

	

		<!-- Two -->
			<section id="two" class="wrapper style2 alt">
				<div class="inner">
					<div class="spotlight">
						<div class="image">
							<img src="images/pic01.jpg" alt="" />
						</div>
						<div class="content">
							<h3>Rohini 	rohini23@gmail.com</h3>
							<p>  
									I was not sure how this process works initially, but after experiencing this for the first time I must say this app is real useful.I wanted to know more about studying abroad.Germany in specific.This app connected me to a fellow student at a university in Germany who told me in detail of the specifications required to get in at any of the German universities.</p>
									<p>Mode of contact :	SKYPE


							</p>
							
						</div>
					</div>
					<div class="spotlight">
						<div class="image">
							<img src="images/pic02.jpg" alt="" />
						</div>
						<div class="content">
							<h3>Rashmi 		rashmi@ymail.com</h3>
							<p>I am a 3rd year medicine student.Wanted more infoormaton as to which field I can major in.This app helped me connect with 2 other women who told me their medicine career.Now I need to make a decision.</p>
							<p>MODE OF CONTACT: Whatsapp. </p>
							
						</div>
					</div>
					<div class="spotlight">
						<div class="image">
							<img src="images/pic03.jpg" alt="" />
						</div>
						<div class="content">
							<h3>Sheila sheila@yahoo.co.in</h3>
							<p>Was alloted a techie who is a software developer.Wanted to know if its better to be a software developer or tester especially because  I am not that great at coding.She helped me see the testing and coding are both important even though many say tester job is looked down upon. Thanks to Miss SHalini ,had coffee wit her yesterday .A real mentor I must say </p>
							<p>		MODE OF CONTACT : Personal meet at a local coffee shop
							 </p>
							
						</div>
					</div>
				
				</div>
			</section>

		<!-- Contact -->
			<section id="contact" class="wrapper">
				<div class="inner split">
					<section>
						<h2>Share your experience...</h2>
						
						<form action="#" class="alt" method="POST">
							<div class="row uniform">
								<div class="6u 12u$(xsmall)">
									<input name="name" placeholder="Name" type="text">
								</div>
								<div class="6u$ 12u$(xsmall)">
									<input name="email" placeholder="Email" type="email">
								</div>
								<div class="12u$">
									<textarea name="message" placeholder="Message" rows="4"></textarea>
 								</div>
 							</div>
 							<ul class="actions">
 								<li><input class="alt" value="POST" type="submit"></li>
 							</ul>
 						</form>
					</section>
					
				</div>
			</section>

		

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>